package com.bc.week10demo2

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.net.toUri
import androidx.databinding.BindingAdapter
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.squareup.picasso.Picasso
import edu.seattleu.unsplash_search.DetailActivity
import edu.seattleu.unsplash_search.R
import edu.seattleu.unsplash_search.databinding.ItemViewBinding


class PropertyListAdapter :
    ListAdapter<MarsProperty, PropertyListAdapter.PropertyViewHolder>(RowItemDiffCallback()) {

    fun setData(data: List<MarsProperty>) {
        submitList(data)
    }

    class PropertyViewHolder private constructor(val binding: ItemViewBinding) :
        RecyclerView.ViewHolder(binding.root) {
        companion object {
            fun from(parent: ViewGroup): PropertyViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding: ItemViewBinding = DataBindingUtil.inflate(
                    layoutInflater,
                    R.layout.item_view, parent, false
                )
                //val binding = ItemViewBinding.inflate(layoutInflater, parent, false)
                return PropertyViewHolder(binding)
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PropertyViewHolder {
        return PropertyViewHolder.from(parent)

    }

    override fun onBindViewHolder(holder: PropertyViewHolder, position: Int) {
        val property = getItem(position)
        holder.binding.property = property
        holder.binding.executePendingBindings()

        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("image_url", property.imageUrls.regular) // pass full image url
            context.startActivity(intent)
        }
    }
}

class RowItemDiffCallback : DiffUtil.ItemCallback<MarsProperty>() {
    override fun areItemsTheSame(oldItem: MarsProperty, newItem: MarsProperty): Boolean {
        Log.v("callback areItemsTheSame", Thread.currentThread().name)
        return oldItem == newItem
    }

    override fun areContentsTheSame(oldItem: MarsProperty, newItem: MarsProperty): Boolean {
        Log.v("callback areContentsTheSame", Thread.currentThread().name)
        return oldItem.id == newItem.id
    }
}


@BindingAdapter("imageUrl")
fun bindImage(imgView: ImageView, imgUrl: String?) {
    imgUrl?.let {
        val imgUri = imgUrl.toUri().buildUpon().scheme("https").build()
        Glide.with(imgView.context)
            .load(imgUrl.replace("http", "https"))
            .apply(
                RequestOptions()
                    .placeholder(R.drawable.loading_animation)
                    .error(R.drawable.ic_broken_image)
            )
            .into(imgView)
    }
}

@BindingAdapter("imageUrl2")
fun bindImage2(imgView: ImageView, imgUrl: String?) {
    imgUrl?.let {
        val imgUri = imgUrl.toUri().buildUpon().scheme("https").build()
        Picasso.get()
            .load(imgUri)
            .resize(200, 200)
            .placeholder(R.drawable.loading_animation)
            .error(R.drawable.ic_broken_image)
            .into(imgView)
    }
}


@BindingAdapter("price")
fun TextView.price(price: Double) {
    text = "Price: ${price.toString()}"
}