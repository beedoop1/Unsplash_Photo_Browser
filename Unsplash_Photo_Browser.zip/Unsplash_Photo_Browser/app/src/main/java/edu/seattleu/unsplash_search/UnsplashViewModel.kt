package com.bc.week10demo2

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class UnsplashViewModel() : ViewModel() {

    private val _properties = MutableLiveData<List<MarsProperty>>()
    val properties: LiveData<List<MarsProperty>>
        get() = _properties

    fun searchPhotos(query: String) {
        viewModelScope.launch {
            try {
                val response = MarsApi.retrofitService.searchPhotos(query)
                _properties.value = response.results
                Log.d("properties", _properties.value.toString())
            } catch (e: Exception) {
                Log.e("ViewModel", "Error: Can't find photos", e)
                _properties.value = emptyList()
            }
        }
    }
}
