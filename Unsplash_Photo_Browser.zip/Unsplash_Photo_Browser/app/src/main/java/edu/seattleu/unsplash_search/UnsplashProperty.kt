package com.bc.week10demo2

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MarsProperty(
    val id: String,
    @Json(name = "urls") val imageUrls: ImageUrls
)

@JsonClass(generateAdapter = true)
data class ImageUrls(
    @Json(name = "regular") val regular: String
)