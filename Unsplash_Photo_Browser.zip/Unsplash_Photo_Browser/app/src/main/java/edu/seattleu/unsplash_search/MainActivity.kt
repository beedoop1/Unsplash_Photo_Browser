package edu.seattleu.unsplash_search

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doOnTextChanged
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bc.week10demo2.UnsplashViewModel
import com.bc.week10demo2.PropertyListAdapter

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val viewModel = ViewModelProvider(this)[UnsplashViewModel::class.java]

        val rv = findViewById<RecyclerView>(R.id.rv)
        rv.layoutManager = GridLayoutManager(this, 2)

        val adapter = PropertyListAdapter()

        viewModel.properties.observe(this){
            if(it!= null){
                adapter.setData(it!!)
            }
        }

        rv.adapter = adapter

        val searchBox = findViewById<EditText>(R.id.searchBox)
        val searchButton = findViewById<ImageButton>(R.id.searchButton)

        searchBox.doOnTextChanged { text, _, _, _ ->
            val enabled = !text.isNullOrEmpty()
            searchButton.isEnabled = enabled
        }

        searchButton.setOnClickListener {
            val query = searchBox.text.toString().trim()
            if (query.isNotEmpty()) {
                viewModel.searchPhotos(query)
            }
        }
    }
}